import Board from "./Board";

function Game() {
	return <Board gridSize={3} />;
}

export default Game;
